//
//  SQLiteWrapper.h
//  SQLiteWrapper
//
//  Created by Vigneshkumar G on 13/08/18.
//  Copyright © 2018 viki. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for SQLiteWrapper.
FOUNDATION_EXPORT double SQLiteWrapperVersionNumber;

//! Project version string for SQLiteWrapper.
FOUNDATION_EXPORT const unsigned char SQLiteWrapperVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SQLiteWrapper/PublicHeader.h>

